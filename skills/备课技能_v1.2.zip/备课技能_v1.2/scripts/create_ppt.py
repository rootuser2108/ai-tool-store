#!/usr/bin/env python3
"""
大师级PPT生成脚本 v1.1
根据JSON格式的内容数据生成专业级PPT文件
新增：education/fresh主题、chart图表布局（柱状图/折线图/饼图）
"""

import argparse
import json
import sys
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt, Emu
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
except ImportError:
    print("错误: 需要安装 python-pptx 库，请执行: pip install python-pptx", file=sys.stderr)
    sys.exit(1)


# 主题配色方案
THEMES = {
    "professional": {
        "primary": RGBColor(0x1A, 0x36, 0x5D),    # 深蓝
        "secondary": RGBColor(0x2E, 0x86, 0xAB),  # 浅蓝
        "accent": RGBColor(0xE8, 0x6F, 0x2C),     # 橙色
        "text_dark": RGBColor(0x2D, 0x2D, 0x2D),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF5, 0xF7, 0xFA),   # 浅灰背景
    },
    "creative": {
        "primary": RGBColor(0x6C, 0x5C, 0xE7),    # 紫色
        "secondary": RGBColor(0x00, 0xCE, 0xC9),  # 青色
        "accent": RGBColor(0xFD, 0x79, 0xA8),     # 粉色
        "text_dark": RGBColor(0x2D, 0x3A, 0x4A),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF8, 0xF9, 0xFA),   # 浅灰背景
    },
    "minimal": {
        "primary": RGBColor(0x33, 0x33, 0x33),    # 深灰
        "secondary": RGBColor(0x66, 0x66, 0x66),  # 中灰
        "accent": RGBColor(0x00, 0x7A, 0xCC),     # 蓝色
        "text_dark": RGBColor(0x1A, 0x1A, 0x1A),  # 黑色
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xFA, 0xFA, 0xFA),   # 极浅灰
    },
    "business": {
        "primary": RGBColor(0x0D, 0x47, 0xA1),    # 商务蓝
        "secondary": RGBColor(0x42, 0xA5, 0xF5),  # 亮蓝
        "accent": RGBColor(0xFF, 0xA0, 0x00),     # 金色
        "text_dark": RGBColor(0x21, 0x21, 0x21),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF5, 0xF5, 0xF5),   # 浅灰
    },
    "education": {
        "primary": RGBColor(0x25, 0x63, 0xEB),    # 活力蓝
        "secondary": RGBColor(0x10, 0xB9, 0x81),  # 草绿
        "accent": RGBColor(0xF5, 0x9E, 0x0B),     # 暖阳黄
        "text_dark": RGBColor(0x1E, 0x29, 0x3B),  # 深灰蓝
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xEF, 0xF6, 0xFF),   # 浅蓝灰
    },
    "fresh": {
        "primary": RGBColor(0xF4, 0x72, 0xB6),    # 珊瑚粉
        "secondary": RGBColor(0x34, 0xD3, 0x99),  # 薄荷绿
        "accent": RGBColor(0x60, 0xA5, 0xFA),     # 天空蓝
        "text_dark": RGBColor(0x37, 0x41, 0x51),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xFF, 0xF1, 0xF2),   # 浅粉白
    },
}

# 图表颜色方案（与主题匹配）
CHART_COLORS = {
    "professional": [RGBColor(0x1A, 0x36, 0x5D), RGBColor(0x2E, 0x86, 0xAB), RGBColor(0xE8, 0x6F, 0x2C)],
    "creative": [RGBColor(0x6C, 0x5C, 0xE7), RGBColor(0x00, 0xCE, 0xC9), RGBColor(0xFD, 0x79, 0xA8)],
    "minimal": [RGBColor(0x33, 0x33, 0x33), RGBColor(0x66, 0x66, 0x66), RGBColor(0x00, 0x7A, 0xCC)],
    "business": [RGBColor(0x0D, 0x47, 0xA1), RGBColor(0x42, 0xA5, 0xF5), RGBColor(0xFF, 0xA0, 0x00)],
    "education": [RGBColor(0x25, 0x63, 0xEB), RGBColor(0x10, 0xB9, 0x81), RGBColor(0xF5, 0x9E, 0x0B)],
    "fresh": [RGBColor(0xF4, 0x72, 0xB6), RGBColor(0x34, 0xD3, 0x99), RGBColor(0x60, 0xA5, 0xFA)],
}

# 字体设置
FONTS = {
    "title_cn": "微软雅黑",
    "title_en": "Calibri",
    "body_cn": "微软雅黑",
    "body_en": "Calibri",
}


def set_slide_bg(slide, color):
    """设置幻灯片背景颜色"""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_shape_with_fill(slide, left, top, width, height, color, shape_type=MSO_SHAPE.RECTANGLE):
    """添加带填充的矩形"""
    shape = slide.shapes.add_shape(shape_type, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    return shape


def add_text_box(slide, left, top, width, height, text, font_size=18, 
                 font_color=None, bold=False, alignment=PP_ALIGN.LEFT, font_name=None):
    """添加文本框"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.alignment = alignment
    if font_color:
        p.font.color.rgb = font_color
    if font_name:
        p.font.name = font_name
    
    return txBox


def add_bullet_list(slide, left, top, width, height, items, font_size=16, 
                    font_color=None, bullet_color=None):
    """添加项目符号列表"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        
        p.text = item
        p.font.size = Pt(font_size)
        p.level = 0
        p.space_before = Pt(8)
        p.space_after = Pt(4)
        if font_color:
            p.font.color.rgb = font_color
    
    return txBox


def create_title_slide(prs, data, theme):
    """创建标题页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 装饰条
    add_shape_with_fill(slide, Inches(0), Inches(3.2), Inches(10), Inches(0.05), theme["accent"])
    
    # 标题
    title = data.get("title", "演示文稿标题")
    add_text_box(slide, Inches(1), Inches(1.8), Inches(8), Inches(1.2),
                 title, font_size=44, font_color=theme["text_light"], 
                 bold=True, alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 副标题
    subtitle = data.get("subtitle", "")
    if subtitle:
        add_text_box(slide, Inches(1), Inches(3.5), Inches(8), Inches(0.8),
                     subtitle, font_size=24, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 作者/日期
    author = data.get("author", "")
    if author:
        add_text_box(slide, Inches(1), Inches(5.5), Inches(8), Inches(0.5),
                     author, font_size=16, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["body_cn"])
    
    return slide


def create_section_slide(prs, slide_data, theme):
    """创建章节分隔页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 左侧装饰条
    add_shape_with_fill(slide, Inches(0.5), Inches(2), Inches(0.1), Inches(3), theme["accent"])
    
    # 章节标题
    title = slide_data.get("title", "章节标题")
    add_text_box(slide, Inches(1.2), Inches(2.8), Inches(7.5), Inches(1.5),
                 title, font_size=40, font_color=theme["text_light"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    # 章节描述
    description = slide_data.get("description", "")
    if description:
        add_text_box(slide, Inches(1.2), Inches(4.5), Inches(7.5), Inches(1),
                     description, font_size=18, font_color=theme["text_light"],
                     alignment=PP_ALIGN.LEFT, font_name=FONTS["body_cn"])
    
    return slide


def create_content_slide(prs, slide_data, theme):
    """创建内容页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["bg_light"])
    
    # 顶部装饰条
    add_shape_with_fill(slide, Inches(0), Inches(0), Inches(10), Inches(0.08), theme["primary"])
    
    # 页面标题
    title = slide_data.get("title", "页面标题")
    add_text_box(slide, Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8),
                 title, font_size=28, font_color=theme["primary"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    # 标题下划线
    add_shape_with_fill(slide, Inches(0.8), Inches(1.2), Inches(2), Inches(0.04), theme["accent"])
    
    # 内容
    content = slide_data.get("content", "")
    if isinstance(content, list):
        add_bullet_list(slide, Inches(0.8), Inches(1.6), Inches(8.4), Inches(5),
                        content, font_size=18, font_color=theme["text_dark"])
    else:
        add_text_box(slide, Inches(0.8), Inches(1.6), Inches(8.4), Inches(5),
                     content, font_size=18, font_color=theme["text_dark"],
                     alignment=PP_ALIGN.LEFT, font_name=FONTS["body_cn"])
    
    # 备注
    notes = slide_data.get("notes", "")
    if notes:
        notes_slide = slide.notes_slide
        notes_slide.notes_text_frame.text = notes
    
    return slide


def create_two_column_slide(prs, slide_data, theme):
    """创建双栏布局页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["bg_light"])
    
    # 顶部装饰条
    add_shape_with_fill(slide, Inches(0), Inches(0), Inches(10), Inches(0.08), theme["primary"])
    
    # 页面标题
    title = slide_data.get("title", "页面标题")
    add_text_box(slide, Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8),
                 title, font_size=28, font_color=theme["primary"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    add_shape_with_fill(slide, Inches(0.8), Inches(1.2), Inches(2), Inches(0.04), theme["accent"])
    
    # 左栏
    left_content = slide_data.get("left_content", [])
    left_title = slide_data.get("left_title", "")
    
    if left_title:
        add_text_box(slide, Inches(0.8), Inches(1.6), Inches(4), Inches(0.6),
                     left_title, font_size=20, font_color=theme["secondary"],
                     bold=True, font_name=FONTS["title_cn"])
    
    if isinstance(left_content, list):
        add_bullet_list(slide, Inches(0.8), Inches(2.2), Inches(4), Inches(4.5),
                        left_content, font_size=16, font_color=theme["text_dark"])
    else:
        add_text_box(slide, Inches(0.8), Inches(2.2), Inches(4), Inches(4.5),
                     str(left_content), font_size=16, font_color=theme["text_dark"])
    
    # 分隔线
    add_shape_with_fill(slide, Inches(5), Inches(1.6), Inches(0.02), Inches(5), theme["secondary"])
    
    # 右栏
    right_content = slide_data.get("right_content", [])
    right_title = slide_data.get("right_title", "")
    
    if right_title:
        add_text_box(slide, Inches(5.3), Inches(1.6), Inches(4), Inches(0.6),
                     right_title, font_size=20, font_color=theme["secondary"],
                     bold=True, font_name=FONTS["title_cn"])
    
    if isinstance(right_content, list):
        add_bullet_list(slide, Inches(5.3), Inches(2.2), Inches(4), Inches(4.5),
                        right_content, font_size=16, font_color=theme["text_dark"])
    else:
        add_text_box(slide, Inches(5.3), Inches(2.2), Inches(4), Inches(4.5),
                     str(right_content), font_size=16, font_color=theme["text_dark"])
    
    return slide


def create_chart_slide(prs, slide_data, theme, theme_name="professional"):
    """创建图表页 - 支持柱状图、折线图、饼图"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["bg_light"])
    
    # 顶部装饰条
    add_shape_with_fill(slide, Inches(0), Inches(0), Inches(10), Inches(0.08), theme["primary"])
    
    # 页面标题
    title = slide_data.get("title", "数据图表")
    add_text_box(slide, Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8),
                 title, font_size=28, font_color=theme["primary"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    # 标题下划线
    add_shape_with_fill(slide, Inches(0.8), Inches(1.2), Inches(2), Inches(0.04), theme["accent"])
    
    # 获取图表数据
    chart_type = slide_data.get("chart_type", "bar")
    chart_title = slide_data.get("chart_title", "")
    categories = slide_data.get("categories", [])
    series_data = slide_data.get("series", [])
    
    # 创建图表数据
    chart_data = CategoryChartData()
    chart_data.categories = categories
    
    for s in series_data:
        chart_data.add_series(s.get("name", "数据"), s.get("values", []))
    
    # 确定图表类型
    if chart_type == "line":
        xl_chart_type = XL_CHART_TYPE.LINE_MARKERS
    elif chart_type == "pie":
        xl_chart_type = XL_CHART_TYPE.PIE
    else:  # bar (default)
        if len(series_data) > 1:
            xl_chart_type = XL_CHART_TYPE.COLUMN_CLUSTERED
        else:
            xl_chart_type = XL_CHART_TYPE.COLUMN_CLUSTERED
    
    # 图表位置和大小
    chart_left = Inches(0.8)
    chart_top = Inches(1.6)
    chart_width = Inches(8.4)
    chart_height = Inches(5.2)
    
    # 添加图表
    chart_frame = slide.shapes.add_chart(
        xl_chart_type, chart_left, chart_top, chart_width, chart_height, chart_data
    )
    chart = chart_frame.chart
    
    # 设置图表标题
    if chart_title:
        chart.has_title = True
        chart.chart_title.text_frame.paragraphs[0].text = chart_title
        chart.chart_title.text_frame.paragraphs[0].font.size = Pt(14)
        chart.chart_title.text_frame.paragraphs[0].font.name = FONTS["title_cn"]
    else:
        chart.has_title = False
    
    # 应用主题颜色到图表系列
    colors = CHART_COLORS.get(theme_name, CHART_COLORS["professional"])
    for i, series in enumerate(chart.series):
        color = colors[i % len(colors)]
        if chart_type == "pie":
            # 饼图：每个扇区不同颜色
            for j in range(len(categories)):
                point = series.points[j]
                point.format.fill.solid()
                point.format.fill.fore_color.rgb = colors[j % len(colors)]
        else:
            # 柱状图/折线图：每个系列一种颜色
            series.format.fill.solid()
            series.format.fill.fore_color.rgb = color
            if chart_type == "line":
                series.smooth = True
    
    # 图例设置
    if chart_type != "pie" or len(series_data) > 1:
        chart.has_legend = True
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False
    else:
        chart.has_legend = False
    
    # 备注
    notes = slide_data.get("notes", "")
    if notes:
        notes_slide = slide.notes_slide
        notes_slide.notes_text_frame.text = notes
    
    return slide


def create_quote_slide(prs, slide_data, theme):
    """创建引用/金句页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 引号装饰
    add_text_box(slide, Inches(1), Inches(1.5), Inches(1), Inches(1),
                 '"', font_size=80, font_color=theme["accent"],
                 bold=True, font_name=FONTS["title_en"])
    
    # 引用内容
    quote = slide_data.get("content", "")
    add_text_box(slide, Inches(1.5), Inches(2.5), Inches(7), Inches(2.5),
                 quote, font_size=28, font_color=theme["text_light"],
                 alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 来源
    source = slide_data.get("source", "")
    if source:
        add_text_box(slide, Inches(1.5), Inches(5.2), Inches(7), Inches(0.5),
                     f"— {source}", font_size=16, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["body_cn"])
    
    return slide


def create_end_slide(prs, data, theme):
    """创建结束页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 装饰条
    add_shape_with_fill(slide, Inches(3), Inches(2.8), Inches(4), Inches(0.05), theme["accent"])
    
    # 感谢文字
    thanks_text = data.get("thanks_text", "感谢聆听")
    add_text_box(slide, Inches(1), Inches(3.2), Inches(8), Inches(1.2),
                 thanks_text, font_size=44, font_color=theme["text_light"],
                 bold=True, alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 联系方式
    contact = data.get("contact", "")
    if contact:
        add_text_box(slide, Inches(1), Inches(4.8), Inches(8), Inches(0.8),
                     contact, font_size=18, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["body_cn"])
    
    return slide


def create_ppt(input_file, output_file, theme_name="professional"):
    """主函数：创建PPT"""
    # 读取JSON数据
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 获取主题
    theme = THEMES.get(theme_name, THEMES["professional"])
    if "theme" in data:
        theme = THEMES.get(data["theme"], theme)
    
    # 创建演示文稿
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    
    # 创建标题页
    create_title_slide(prs, data, theme)
    
    # 创建内容页
    slides = data.get("slides", [])
    for slide_data in slides:
        layout = slide_data.get("layout", "content")
        
        if layout == "section":
            create_section_slide(prs, slide_data, theme)
        elif layout == "two_column":
            create_two_column_slide(prs, slide_data, theme)
        elif layout == "chart":
            create_chart_slide(prs, slide_data, theme, theme_name)
        elif layout == "quote":
            create_quote_slide(prs, slide_data, theme)
        elif layout == "end":
            create_end_slide(prs, slide_data, theme)
        else:  # content
            create_content_slide(prs, slide_data, theme)
    
    # 如果没有结束页，添加一个
    if not slides or slides[-1].get("layout") != "end":
        create_end_slide(prs, {"thanks_text": "感谢聆听"}, theme)
    
    # 保存文件
    prs.save(output_file)
    
    result = {
        "status": "success",
        "output_file": str(output_file),
        "slide_count": len(prs.slides),
        "theme": theme_name
    }
    print(json.dumps(result, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description="大师级PPT生成脚本 v1.1")
    parser.add_argument("--input", required=True, help="JSON内容文件路径")
    parser.add_argument("--output", required=True, help="输出PPT文件路径")
    parser.add_argument("--theme", default="professional", 
                        choices=["professional", "creative", "minimal", "business", "education", "fresh"],
                        help="主题风格")
    args = parser.parse_args()
    
    # 验证输入文件
    if not Path(args.input).exists():
        print(json.dumps({"status": "error", "message": f"输入文件不存在: {args.input}"}, ensure_ascii=False))
        sys.exit(1)
    
    try:
        create_ppt(args.input, args.output, args.theme)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
