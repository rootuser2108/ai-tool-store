---
name: master-ppt-creator
description: 提供大师级PPT制作能力，涵盖内容策划、结构设计、视觉设计、排版布局与PPT文件生成；当用户需要制作PPT、创建演示文稿、设计幻灯片或生成专业级PPT文件时使用
dependency:
  python:
    - python-pptx>=0.6.21
---

# 大师级PPT制作 v1.2

## 任务目标
- 本 Skill 用于:制作专业级演示文稿PPT，支持教案备课与课件联动
- 能力包含:内容策划、结构设计、视觉设计、排版布局、数据图表、教案→PPT联动、PPT文件生成
- 触发条件:用户需要制作PPT、创建演示文稿、设计幻灯片、制作课件、教案备课

## 前置准备
- 依赖说明:脚本需要 python-pptx 库

## 操作步骤

### 步骤1：分析PPT需求
与用户确认以下信息:
- **主题**:PPT的核心主题与目的
- **受众**:目标听众(领导/客户/学生/同事等)
- **场景**:汇报/演讲/培训/教学/展示等
- **时长**:预计演讲时长，决定页数(一般1页/分钟)
- **风格**:专业/创意/简约/商务/教育/清新

### 步骤2：策划内容结构
根据PPT类型参考 [references/content-structure.md](references/content-structure.md) 选择合适的内容结构:
- 工作汇报型:背景→成果→问题→计划
- 产品介绍型:痛点→方案→优势→案例→行动
- 培训课件型:导入→知识→练习→总结
- 商业计划型:市场→产品→模式→团队→财务
- **教案备课型**:目标→学情→导入→讲解→例题→练习→总结

> **教案→PPT联动**：如果用户已有教案或需要先制作教案再生成配套课件，请跳转至步骤2B。

### 步骤2B：教案→PPT联动工作流（新增）

当用户需要从教案直接生成配套PPT时，参考 [references/teaching-workflow.md](references/teaching-workflow.md) 执行联动工作流：

1. **生成教案JSON**：根据用户输入的教学需求，按教案JSON结构组织内容，包含：
   - `teaching_objectives`：教学目标（知识与技能、过程与方法、情感态度与价值观）
   - `student_analysis`：学情分析（已有基础、学习难点、教学策略）
   - `teaching_process`：教学过程（导入、讲解、例题、练习、总结各环节）
   - `exercise_design`：习题设计（支持选择题、填空题、案例分析题、综合应用题、小组讨论题、课堂辩论题、思维导图题、实验报告题等）

2. **教案→PPT转换**：按照映射规则将教案JSON转换为PPT JSON格式：
   - 教学目标 → 封面页+教学目标页
   - 学情分析 → 学情分析页（two_column布局）
   - 教学过程各环节 → 对应PPT页面（section分隔+content内容页）
   - 习题设计 → 课堂练习页（根据题型选择content/two_column等布局）
   - 教学反思 → 可选反思页

3. **生成PPT文件**：使用转换后的PPT JSON调用脚本生成PPT

> 不同学科（语文/数学/英语/物理/化学/历史）有对应的教学流程模板，详见 [references/teaching-workflow.md](references/teaching-workflow.md)。

### 步骤3：设计视觉风格
参考 [references/design-principles.md](references/design-principles.md) 确定:
- **配色方案**:从6种预设主题选择
  - professional：工作汇报、正式场合
  - creative：产品发布、创意展示
  - minimal：培训课件、学术报告
  - business：商业计划、客户提案
  - **education：教学课件、课堂演示**（推荐教学场景首选）
  - **fresh：幼教课件、趣味教学**（推荐低龄教学场景）
- **字体规范**:标题用微软雅黑/Calibri，正文用微软雅黑/Calibri
- **视觉层次**:通过字号、颜色、粗细建立信息层级

### 步骤4：编写PPT内容JSON
将策划好的内容组织为JSON格式，参考 [references/layout-templates.md](references/layout-templates.md) 了解各布局类型:

```json
{
  "title": "PPT主标题",
  "subtitle": "副标题或说明",
  "author": "作者/部门/日期",
  "theme": "education",
  "slides": [
    {
      "layout": "section",
      "title": "章节标题",
      "description": "章节说明"
    },
    {
      "layout": "content",
      "title": "页面标题",
      "content": ["要点1", "要点2", "要点3"],
      "notes": "演讲备注"
    },
    {
      "layout": "chart",
      "title": "成绩对比分析",
      "chart_type": "bar",
      "chart_title": "各班级期末平均分",
      "categories": ["一班", "二班", "三班", "四班"],
      "series": [
        {"name": "期中", "values": [78, 82, 75, 80]},
        {"name": "期末", "values": [85, 88, 82, 86]}
      ]
    },
    {
      "layout": "two_column",
      "title": "对比分析",
      "left_title": "方案A",
      "left_content": ["内容1", "内容2"],
      "right_title": "方案B",
      "right_content": ["内容1", "内容2"]
    },
    {
      "layout": "quote",
      "content": "金句或引用内容",
      "source": "来源"
    },
    {
      "layout": "end",
      "thanks_text": "感谢聆听",
      "contact": "联系方式"
    }
  ]
}
```

**布局类型说明**:
| layout | 用途 | 关键字段 |
|--------|------|----------|
| title | 标题页(自动生成) | title, subtitle, author |
| section | 章节分隔页 | title, description |
| content | 内容页 | title, content(文本或列表), notes |
| **chart** | **数据图表页** | **chart_type(bar/line/pie), chart_title, categories, series** |
| two_column | 双栏对比页 | title, left_title, left_content, right_title, right_content |
| quote | 金句引用页 | content, source |
| end | 结束页(自动生成) | thanks_text, contact |

### 步骤5：生成PPT文件
将JSON保存为文件后调用脚本:

```bash
python scripts/create_ppt.py --input ppt_content.json --output output.pptx --theme education
```

**参数说明**:
- `--input`: JSON内容文件路径(必填)
- `--output`: 输出PPT文件路径(必填)
- `--theme`: 主题风格，可选 professional/creative/minimal/business/education/fresh(默认professional)

**输出**: JSON格式结果，包含状态、输出文件路径、页数、主题

## 使用示例

### 示例1：工作汇报PPT
- 场景/输入:用户需要制作季度工作汇报PPT
- 预期产出:10-15页专业风格工作汇报PPT
- 关键要点:
  - 结构:工作概述→重点成果→数据分析→问题反思→下季计划
  - 配色:professional主题，稳重专业
  - 配合chart图表展示关键数据

### 示例2：教学课件PPT
- 场景/输入:用户需要制作小学数学教学课件
- 预期产出:15-20页教育风格课件
- 关键要点:
  - 结构:教学目标→情境导入→知识讲解→例题示范→课堂练习→总结
  - 配色:education主题，活力蓝+草绿+暖阳黄
  - 用chart图表展示数据（如成绩对比、时间分配）
  - 字体适当放大（正文20pt以上）

### 示例3：产品介绍PPT
- 场景/输入:用户需要制作产品发布演示PPT
- 预期产出:15-20页创意风格产品介绍PPT
- 关键要点:
  - 结构:市场痛点→产品方案→核心优势→客户案例→行动号召
  - 配色:creative主题，活力创新
  - 突出视觉冲击，每页一个核心信息

### 示例4：幼儿园课件
- 场景/输入:用户需要制作幼儿园语言课课件
- 预期产出:12-15页清新风格课件
- 关键要点:
  - 结构:故事导入→图片认读→互动游戏→总结
  - 配色:fresh主题，珊瑚粉+薄荷绿+天空蓝
  - 字号偏大(22pt+)，内容精简

### 示例5：教案→PPT联动（新增）
- 场景/输入:用户需要制作八年级物理《浮力》一课的教案和配套课件
- 预期产出:完整教案JSON + 配套15-20页education主题课件PPT
- 关键要点:
  - 先按教案JSON结构生成教案：包含教学目标（理解浮力概念、掌握阿基米德原理）、学情分析（已学力与运动、容易混淆浮力方向）、教学过程（情境导入→概念讲解→实验探究→例题→练习→总结）、习题设计（选择题2道+实验探究题1道+综合应用题1道）
  - 按映射规则转换为PPT JSON：教学目标→目标页、学情分析→two_column页、教学过程→section+content组合、习题→content/two_column页
  - 配色:education主题
  - 习题页根据题型选择合适布局：实验探究题用two_column（左假设右验证）、综合应用题用content列表

## 资源索引
- 脚本:见 [scripts/create_ppt.py](scripts/create_ppt.py)(用途:根据JSON内容生成PPT文件，参数:--input/--output/--theme)
- 参考:见 [references/design-principles.md](references/design-principles.md)(何时读取:需要详细设计指导时)
- 参考:见 [references/content-structure.md](references/content-structure.md)(何时读取:需要内容结构模板时)
- 参考:见 [references/layout-templates.md](references/layout-templates.md)(何时读取:需要了解页面布局详情时)
- 参考:见 [references/teaching-workflow.md](references/teaching-workflow.md)(何时读取:需要教案→PPT联动工作流、教案JSON结构定义、学科教学流程模板时)

## 注意事项
- PPT内容遵循"一页一重点"原则，避免信息过载
- 文字精炼，每页正文不超过6行，每行不超过15字
- 善用视觉层次:标题>副标题>正文>注释
- 配色不超过3种主色，保持视觉统一
- 脚本自动添加标题页和结束页，JSON中无需重复定义
- 教学场景优先选择education或fresh主题，比business更贴合教学氛围
- chart图表支持柱状图(bar)、折线图(line)、饼图(pie)，数据自动配色
- 充分利用智能体能力进行内容策划，脚本负责文件生成
- 教案→PPT联动时，教案JSON是中间产物，最终通过PPT JSON调用脚本生成PPT
- 习题设计灵活选择布局：简单题用content，对比/流程题用two_column，数据题用chart

## 版本记录
- v1.2 (2026-07-06): 新增教案→PPT联动工作流（步骤2B）、新增teaching-workflow.md参考文档、扩展习题类型（新增案例分析题/综合应用题/小组讨论题/课堂辩论题/思维导图题/实验报告题）、新增教案→PPT联动示例（示例5）、SKILL.md更突出教育场景定位
- v1.1 (2026-07-06): 新增education/fresh教育主题配色、新增chart图表布局(柱状图/折线图/饼图)、新增教案备课结构模板、新增教材版本适配指南、新增图表设计规范
- v1.0 (2026-07-06): 初始版本，6种布局模板、4种主题配色、6种内容结构
