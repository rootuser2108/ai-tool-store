#!/usr/bin/env python3
"""简历 HTML/PDF/DOCX 生成器 - 将 JSON 简历数据渲染为专业 HTML、PDF 或 Word(docx) 文件"""

import argparse
import json
import os
import re
import sys
from html import escape


def resolve_var(path, data):
    """解析点号分隔的变量路径，如 contact.phone"""
    keys = path.strip().split(".")
    val = data
    for k in keys:
        if isinstance(val, dict) and k in val:
            val = val[k]
        else:
            return ""
    if val is None:
        return ""
    return escape(str(val))


def get_list(path, data):
    """获取列表型数据"""
    keys = path.strip().split(".")
    val = data
    for k in keys:
        if isinstance(val, dict) and k in val:
            val = val[k]
        else:
            return []
    return val if isinstance(val, list) else []


def render_for_blocks(template, data):
    """处理 {% for item in list %}...{% endfor %} 循环块"""
    pattern = r'\{%\s*for\s+(\w+)\s+in\s+([\w.]+)\s*%\}(.*?)\{%\s*endfor\s*%\}'

    def replace_loop(match):
        item_name = match.group(1)
        list_path = match.group(2)
        body = match.group(3)
        items = get_list(list_path, data)

        if not items:
            return ""

        result_parts = []
        for item in items:
            rendered = body
            if isinstance(item, dict):
                # 处理嵌套的 for 循环(如 experience.highlights)
                rendered = render_for_blocks(rendered, {**data, item_name: item})
                # 替换 {{item.xxx}} 变量
                for key, value in item.items():
                    if isinstance(value, list):
                        continue
                    placeholder = "{{" + item_name + "." + key + "}}"
                    rendered = rendered.replace(placeholder, escape(str(value)) if value else "")
            else:
                placeholder = "{{" + item_name + "}}"
                rendered = rendered.replace(placeholder, escape(str(item)))
            result_parts.append(rendered)

        return "".join(result_parts)

    # 循环处理嵌套的 for 块
    prev = None
    while prev != template:
        prev = template
        template = re.sub(pattern, replace_loop, template, flags=re.DOTALL)

    return template


def render_if_blocks(template, data):
    """处理 {% if var %}...{% endif %} 条件块"""
    pattern = r'\{%\s*if\s+([\w.]+)\s*%\}(.*?)\{%\s*endif\s*%\}'

    def replace_if(match):
        var_path = match.group(1)
        body = match.group(2)
        val = resolve_var(var_path, data)
        # 检查列表是否非空
        list_val = get_list(var_path, data)
        if val or list_val:
            return body
        return ""

    prev = None
    while prev != template:
        prev = template
        template = re.sub(pattern, replace_if, template, flags=re.DOTALL)

    return template


def render_variables(template, data):
    """替换 {{var}} 变量"""
    def replace_var(match):
        path = match.group(1)
        return resolve_var(path, data)

    return re.sub(r'\{\{([\w.]+)\}\}', replace_var, template)


def render_template(template_str, data):
    """完整渲染流程:循环 -> 条件 -> 变量"""
    result = render_for_blocks(template_str, data)
    result = render_if_blocks(result, data)
    result = render_variables(result, data)
    # 清理多余空行
    result = re.sub(r'\n{3,}', '\n\n', result)
    return result


def load_template(template_name, skill_root):
    """加载模板文件"""
    assets_dir = os.path.join(skill_root, "assets")
    template_path = os.path.join(assets_dir, f"{template_name}.html")
    if not os.path.exists(template_path):
        available = [f.replace(".html", "") for f in os.listdir(assets_dir) if f.endswith(".html")]
        print(json.dumps({
            "status": "error",
            "message": f"模板 '{template_name}' 不存在，可用模板: {', '.join(available)}"
        }, ensure_ascii=False))
        sys.exit(1)
    with open(template_path, "r", encoding="utf-8") as f:
        return f.read()


def load_data(data_arg):
    """加载 JSON 数据(支持字符串或文件路径)"""
    if os.path.isfile(data_arg):
        with open(data_arg, "r", encoding="utf-8") as f:
            return json.load(f)
    else:
        return json.loads(data_arg)


# ============================================================
# PDF 导出
# ============================================================

def export_pdf_with_weasyprint(html_content, output_path):
    """使用 weasyprint 将 HTML 导出为 PDF"""
    from weasyprint import HTML
    HTML(string=html_content).write_pdf(output_path)
    return True


def export_pdf_fallback(html_content, output_path):
    """Fallback: 使用内置简单方案生成 PDF (通过 subprocess 调用 wkhtmltopdf 或提示用户)"""
    # 尝试 wkhtmltopdf
    import subprocess
    try:
        result = subprocess.run(
            ["wkhtmltopdf", "--version"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            # wkhtmltopdf 可用，先写临时HTML再转PDF
            tmp_html = output_path + ".tmp.html"
            with open(tmp_html, "w", encoding="utf-8") as f:
                f.write(html_content)
            subprocess.run(
                ["wkhtmltopdf", "--encoding", "utf-8", "--page-size", "A4",
                 "--margin-top", "15mm", "--margin-bottom", "15mm",
                 "--margin-left", "20mm", "--margin-right", "20mm",
                 tmp_html, output_path],
                capture_output=True, text=True, timeout=30
            )
            os.remove(tmp_html)
            if os.path.exists(output_path):
                return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    return False


def export_pdf(html_content, output_path):
    """导出 PDF: 优先 weasyprint, fallback 到 wkhtmltopdf, 最终提示用户"""
    # 方案1: weasyprint
    try:
        if export_pdf_with_weasyprint(html_content, output_path):
            return "weasyprint"
    except ImportError:
        pass
    except Exception as e:
        print(json.dumps({
            "status": "warning",
            "message": f"weasyprint 导出失败: {str(e)}，尝试 fallback 方案"
        }, ensure_ascii=False))

    # 方案2: wkhtmltopdf fallback
    if export_pdf_fallback(html_content, output_path):
        return "wkhtmltopdf"

    # 两种方案都不可用，保存 HTML 并提示用户
    html_fallback = output_path.replace(".pdf", ".html")
    with open(html_fallback, "w", encoding="utf-8") as f:
        f.write(html_content)
    return None


# ============================================================
# DOCX 导出 (v1.2 新增)
# ============================================================

# 模板风格配色方案
DOCX_STYLES = {
    "classic": {
        "font_family": "Times New Roman",
        "font_family_cn": "宋体",
        "name_color": "1A1A1A",
        "title_color": "444444",
        "section_color": "1A1A1A",
        "accent_color": "1A1A1A",
        "header_align": "center",
        "section_uppercase": True,
        "border_color": "1A1A1A",
    },
    "modern": {
        "font_family": "Arial",
        "font_family_cn": "微软雅黑",
        "name_color": "1A365D",
        "title_color": "3182CE",
        "section_color": "3182CE",
        "accent_color": "3182CE",
        "header_align": "left",
        "section_uppercase": True,
        "border_color": "3182CE",
    },
    "creative": {
        "font_family": "Arial",
        "font_family_cn": "微软雅黑",
        "name_color": "FFFFFF",
        "title_color": "BEE3F8",
        "section_color": "2B6CB0",
        "accent_color": "3182CE",
        "header_align": "left",
        "section_uppercase": False,
        "border_color": "2B6CB0",
    },
}


def _set_cell_shading(cell, color_hex):
    """设置表格单元格背景色"""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    shading = OxmlElement('w:shd')
    shading.set(qn('w:fill'), color_hex)
    shading.set(qn('w:val'), 'clear')
    cell._tc.get_or_add_tcPr().append(shading)


def _set_cell_border(cell, **kwargs):
    """设置单元格边框
    kwargs: top/bottom/left/right -> dict(sz, val, color)
    """
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = OxmlElement('w:tcBorders')
    for edge in ('top', 'left', 'bottom', 'right'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:{}'.format(edge)
            element = OxmlElement(tag)
            element.set(qn('w:val'), edge_data.get('val', 'single'))
            element.set(qn('w:sz'), str(edge_data.get('sz', 4)))
            element.set(qn('w:color'), edge_data.get('color', '000000'))
            tcBorders.append(element)
    tcPr.append(tcBorders)


def _add_horizontal_rule(doc, color_hex="CCCCCC", size=6):
    """在文档中添加一条水平分隔线"""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), str(size))
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), color_hex)
    pBdr.append(bottom)
    pPr.append(pBdr)
    return p


def _set_run_font(run, font_family, font_family_cn, color_hex=None, size=None, bold=False):
    """统一设置 run 的字体（西文+中文）、颜色、大小、粗体"""
    from docx.oxml.ns import qn
    run.bold = bold
    if size:
        run.font.size = size
    if color_hex:
        run.font.color.rgb = __import__('docx.shared', fromlist=['RgbColor']).RGBColor.from_string(color_hex)
    run.font.name = font_family
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = __import__('docx.oxml', fromlist=['OxmlElement']).OxmlElement('w:rFonts')
        rPr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), font_family_cn)
    rFonts.set(qn('w:ascii'), font_family)
    rFonts.set(qn('w:hAnsi'), font_family)


def _add_section_title(doc, title, style_cfg):
    """添加分节标题"""
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    text = title.upper() if style_cfg["section_uppercase"] else title
    p = doc.add_paragraph()
    p.space_before = Pt(6)
    p.space_after = Pt(4)
    run = p.add_run(text)
    _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                  color_hex=style_cfg["section_color"], size=Pt(14), bold=True)
    # 添加下边框
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '6')
    bottom.set(qn('w:space'), '2')
    bottom.set(qn('w:color'), style_cfg["border_color"])
    pBdr.append(bottom)
    pPr.append(pBdr)
    return p


def _add_bullet_list(doc, items, style_cfg):
    """添加项目符号列表"""
    from docx.shared import Pt, RGBColor
    for item in items:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(str(item))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex="333333", size=Pt(10.5))
        p.paragraph_format.space_after = Pt(2)


def _add_contact_header(doc, data, style_cfg):
    """添加联系信息头部"""
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    template = style_cfg.get("_template", "classic")

    if template == "creative":
        # creative: 使用表格模拟彩色头部带
        table = doc.add_table(rows=1, cols=1)
        table.autofit = True
        cell = table.cell(0, 0)
        _set_cell_shading(cell, "1A365D")
        _set_cell_border(cell,
                         top={'val': 'nil'}, bottom={'val': 'nil'},
                         left={'val': 'nil'}, right={'val': 'nil'})
        # 姓名
        p_name = cell.paragraphs[0]
        p_name.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run = p_name.add_run(str(data.get("name", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex="FFFFFF", size=Pt(26), bold=True)
        # 职位
        title = data.get("title", "")
        if title:
            p_title = cell.add_paragraph()
            p_title.alignment = WD_ALIGN_PARAGRAPH.LEFT
            run = p_title.add_run(str(title))
            _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                          color_hex="BEE3F8", size=Pt(13))
        # 联系方式
        contact = data.get("contact", {})
        contact_parts = []
        for key in ("phone", "email", "location", "website", "linkedin"):
            val = contact.get(key, "")
            if val:
                contact_parts.append(str(val))
        if contact_parts:
            p_contact = cell.add_paragraph()
            p_contact.alignment = WD_ALIGN_PARAGRAPH.LEFT
            run = p_contact.add_run("  |  ".join(contact_parts))
            _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                          color_hex="E2E8F0", size=Pt(10))
    else:
        # classic / modern: 标准头部
        align = WD_ALIGN_PARAGRAPH.CENTER if style_cfg["header_align"] == "center" else WD_ALIGN_PARAGRAPH.LEFT

        # 姓名
        p_name = doc.add_paragraph()
        p_name.alignment = align
        run = p_name.add_run(str(data.get("name", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex=style_cfg["name_color"], size=Pt(26), bold=True)

        # 职位
        title = data.get("title", "")
        if title:
            p_title = doc.add_paragraph()
            p_title.alignment = align
            run = p_title.add_run(str(title))
            _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                          color_hex=style_cfg["title_color"], size=Pt(13))

        # 联系方式
        contact = data.get("contact", {})
        contact_parts = []
        for key in ("phone", "email", "location", "website", "linkedin"):
            val = contact.get(key, "")
            if val:
                contact_parts.append(str(val))
        if contact_parts:
            p_contact = doc.add_paragraph()
            p_contact.alignment = align
            run = p_contact.add_run("  |  ".join(contact_parts))
            _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                          color_hex="555555", size=Pt(10))

    # 头部分隔线
    _add_horizontal_rule(doc, color_hex=style_cfg["border_color"], size=12 if template == "modern" else 8)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _add_experience_section(doc, data, style_cfg):
    """添加工作经历"""
    from docx.shared import Pt
    items = data.get("experience", [])
    if not items:
        return
    _add_section_title(doc, "工作经历", style_cfg)
    for exp in items:
        # 公司 + 时间 (表格两列布局)
        table = doc.add_table(rows=1, cols=2)
        table.autofit = True
        left_cell = table.cell(0, 0)
        right_cell = table.cell(0, 1)
        # 去除边框
        for cell in (left_cell, right_cell):
            _set_cell_border(cell,
                             top={'val': 'nil'}, bottom={'val': 'nil'},
                             left={'val': 'nil'}, right={'val': 'nil'})

        p_left = left_cell.paragraphs[0]
        run = p_left.add_run(str(exp.get("company", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex=style_cfg["name_color"], size=Pt(12), bold=True)

        p_right = right_cell.paragraphs[0]
        p_right.alignment = __import__('docx.enum.text', fromlist=['WD_ALIGN_PARAGRAPH']).WD_ALIGN_PARAGRAPH.RIGHT
        run = p_right.add_run(str(exp.get("period", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex="666666", size=Pt(10))

        # 职位
        position = exp.get("position", "")
        if position:
            p_pos = doc.add_paragraph()
            p_pos.paragraph_format.space_before = Pt(0)
            run = p_pos.add_run(str(position))
            _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                          color_hex="555555", size=Pt(11))

        # 成果要点
        highlights = exp.get("highlights", [])
        if highlights:
            _add_bullet_list(doc, highlights, style_cfg)

        doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _add_projects_section(doc, data, style_cfg):
    """添加项目经验"""
    from docx.shared import Pt
    items = data.get("projects", [])
    if not items:
        return
    _add_section_title(doc, "项目经验", style_cfg)
    for proj in items:
        # 项目名 + 角色
        table = doc.add_table(rows=1, cols=2)
        table.autofit = True
        left_cell = table.cell(0, 0)
        right_cell = table.cell(0, 1)
        for cell in (left_cell, right_cell):
            _set_cell_border(cell,
                             top={'val': 'nil'}, bottom={'val': 'nil'},
                             left={'val': 'nil'}, right={'val': 'nil'})

        p_left = left_cell.paragraphs[0]
        run = p_left.add_run(str(proj.get("name", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex=style_cfg["name_color"], size=Pt(12), bold=True)

        p_right = right_cell.paragraphs[0]
        p_right.alignment = __import__('docx.enum.text', fromlist=['WD_ALIGN_PARAGRAPH']).WD_ALIGN_PARAGRAPH.RIGHT
        run = p_right.add_run(str(proj.get("role", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex="666666", size=Pt(10))

        # 项目描述
        desc = proj.get("description", "")
        if desc:
            p_desc = doc.add_paragraph()
            run = p_desc.add_run(str(desc))
            _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                          color_hex="555555", size=Pt(10.5))

        highlights = proj.get("highlights", [])
        if highlights:
            _add_bullet_list(doc, highlights, style_cfg)

        doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _add_education_section(doc, data, style_cfg):
    """添加教育背景 (表格形式)"""
    from docx.shared import Pt
    items = data.get("education", [])
    if not items:
        return
    _add_section_title(doc, "教育背景", style_cfg)

    table = doc.add_table(rows=len(items), cols=3)
    table.style = 'Table Grid'
    for i, edu in enumerate(items):
        row = table.rows[i]
        # 学校
        cell_school = row.cells[0]
        p = cell_school.paragraphs[0]
        run = p.add_run(str(edu.get("school", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex=style_cfg["name_color"], size=Pt(11), bold=True)
        # 学历/专业
        cell_detail = row.cells[1]
        p = cell_detail.paragraphs[0]
        degree = edu.get("degree", "")
        major = edu.get("major", "")
        detail = " / ".join([d for d in [degree, major] if d])
        run = p.add_run(detail)
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex="555555", size=Pt(10.5))
        # 时间
        cell_period = row.cells[2]
        p = cell_period.paragraphs[0]
        p.alignment = __import__('docx.enum.text', fromlist=['WD_ALIGN_PARAGRAPH']).WD_ALIGN_PARAGRAPH.RIGHT
        run = p.add_run(str(edu.get("period", "")))
        _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                      color_hex="666666", size=Pt(10))

    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _add_skills_section(doc, data, style_cfg):
    """添加专业技能"""
    from docx.shared import Pt
    skills = data.get("skills", [])
    if not skills:
        return
    _add_section_title(doc, "专业技能", style_cfg)
    # 技能以逗号分隔的段落形式展示
    p = doc.add_paragraph()
    run = p.add_run("  ·  ".join(str(s) for s in skills))
    _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                  color_hex="333333", size=Pt(10.5))
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _add_certificates_section(doc, data, style_cfg):
    """添加资格证书"""
    from docx.shared import Pt
    certs = data.get("certificates", [])
    if not certs:
        return
    _add_section_title(doc, "资格证书", style_cfg)
    p = doc.add_paragraph()
    run = p.add_run("  ·  ".join(str(c) for c in certs))
    _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                  color_hex="333333", size=Pt(10.5))
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _add_languages_section(doc, data, style_cfg):
    """添加语言能力"""
    from docx.shared import Pt
    langs = data.get("languages", [])
    if not langs:
        return
    _add_section_title(doc, "语言能力", style_cfg)
    p = doc.add_paragraph()
    run = p.add_run("  ·  ".join(str(l) for l in langs))
    _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                  color_hex="333333", size=Pt(10.5))
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _add_summary_section(doc, data, style_cfg):
    """添加个人摘要"""
    from docx.shared import Pt
    summary = data.get("summary", "")
    if not summary:
        return
    _add_section_title(doc, "个人摘要", style_cfg)
    p = doc.add_paragraph()
    run = p.add_run(str(summary))
    _set_run_font(run, style_cfg["font_family"], style_cfg["font_family_cn"],
                  color_hex="333333", size=Pt(11))
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def generate_docx(data, template_name, output_path):
    """使用 python-docx 将简历 JSON 数据生成 Word 文档

    支持三种模板风格映射:
    - classic: 传统排版 (衬线字体、黑白配色、居中头部)
    - modern:  现代简约 (无衬线字体、蓝色点缀、左对齐头部)
    - creative: 创意设计 (彩色头部带、蓝色强调)
    """
    try:
        from docx import Document
        from docx.shared import Pt, Inches, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
    except ImportError:
        return None, "python-docx 未安装，请运行: pip install python-docx"

    style_cfg = DOCX_STYLES.get(template_name, DOCX_STYLES["modern"])
    style_cfg["_template"] = template_name

    doc = Document()

    # 设置页面边距
    for section in doc.sections:
        section.top_margin = Inches(0.6)
        section.bottom_margin = Inches(0.6)
        section.left_margin = Inches(0.7)
        section.right_margin = Inches(0.7)

    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = style_cfg["font_family"]
    style.font.size = Pt(11)
    rPr = style.element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        from docx.oxml import OxmlElement
        rFonts = OxmlElement('w:rFonts')
        rPr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), style_cfg["font_family_cn"])

    # 1. 联系信息头部
    _add_contact_header(doc, data, style_cfg)

    # 2. 个人摘要
    _add_summary_section(doc, data, style_cfg)

    # 3. 工作经历
    _add_experience_section(doc, data, style_cfg)

    # 4. 项目经验
    _add_projects_section(doc, data, style_cfg)

    # 5. 教育背景 (表格)
    _add_education_section(doc, data, style_cfg)

    # 6. 专业技能
    _add_skills_section(doc, data, style_cfg)

    # 7. 资格证书
    _add_certificates_section(doc, data, style_cfg)

    # 8. 语言能力
    _add_languages_section(doc, data, style_cfg)

    doc.save(output_path)
    return True, None


# ============================================================
# 主函数
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="简历 HTML/PDF/DOCX 生成器")
    parser.add_argument("--data", required=True, help="JSON 数据字符串或 JSON 文件路径")
    parser.add_argument("--template", required=True, help="模板名称: classic / modern / creative")
    parser.add_argument("--output", required=True, help="输出文件路径(根据 --format 自动确定扩展名)")
    parser.add_argument("--format", dest="fmt", default="html", choices=["html", "pdf", "docx"],
                        help="输出格式: html(默认) / pdf / docx")
    args = parser.parse_args()

    try:
        data = load_data(args.data)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        print(json.dumps({
            "status": "error",
            "message": f"数据加载失败: {str(e)}"
        }, ensure_ascii=False))
        sys.exit(1)

    # 确保输出目录存在
    output_path = os.path.abspath(args.output)
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)

    if args.fmt == "docx":
        # DOCX 导出 (v1.2 新增)
        docx_output = output_path
        if not docx_output.endswith(".docx"):
            docx_output = os.path.splitext(output_path)[0] + ".docx"

        success, error = generate_docx(data, args.template, docx_output)

        if success:
            print(json.dumps({
                "status": "success",
                "output": docx_output,
                "template": args.template,
                "format": "docx",
                "message": f"简历Word文档已生成: {docx_output}"
            }, ensure_ascii=False))
        else:
            print(json.dumps({
                "status": "error",
                "message": error or "DOCX生成失败"
            }, ensure_ascii=False))
            sys.exit(1)

    elif args.fmt == "pdf":
        # PDF 导出 (需先渲染 HTML)
        skill_root = os.path.dirname(os.path.abspath(__file__))
        skill_root = os.path.dirname(skill_root)
        template_str = load_template(args.template, skill_root)
        html_content = render_template(template_str, data)

        pdf_output = output_path
        if not pdf_output.endswith(".pdf"):
            pdf_output = os.path.splitext(output_path)[0] + ".pdf"

        result = export_pdf(html_content, pdf_output)

        if result:
            print(json.dumps({
                "status": "success",
                "output": pdf_output,
                "template": args.template,
                "format": "pdf",
                "engine": result,
                "message": f"简历PDF已生成: {pdf_output} (引擎: {result})"
            }, ensure_ascii=False))
        else:
            html_fallback = pdf_output.replace(".pdf", ".html")
            print(json.dumps({
                "status": "partial",
                "output": html_fallback,
                "template": args.template,
                "format": "html",
                "message": f"PDF依赖不可用(weasyprint/wkhtmltopdf均未安装)，已生成HTML: {html_fallback}。建议安装weasyprint(pip install weasyprint)或用浏览器打开HTML后打印为PDF。"
            }, ensure_ascii=False))
    else:
        # HTML 导出 (默认行为，向后兼容)
        skill_root = os.path.dirname(os.path.abspath(__file__))
        skill_root = os.path.dirname(skill_root)
        template_str = load_template(args.template, skill_root)
        html_content = render_template(template_str, data)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        print(json.dumps({
            "status": "success",
            "output": output_path,
            "template": args.template,
            "format": "html",
            "message": f"简历已生成: {output_path}"
        }, ensure_ascii=False))


if __name__ == "__main__":
    main()
