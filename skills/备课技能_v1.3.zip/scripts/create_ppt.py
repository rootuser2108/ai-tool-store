#!/usr/bin/env python3
"""
大师级PPT生成脚本 v1.3
根据JSON格式的内容数据生成专业级PPT文件
新增：nature/ocean/warm/ink/playful五种教育风格主题、教材版本对接(--textbook参数)
"""

import argparse
import json
import sys
from pathlib import Path

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt, Emu
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
except ImportError:
    print("错误: 需要安装 python-pptx 库，请执行: pip install python-pptx", file=sys.stderr)
    sys.exit(1)


# 主题配色方案
THEMES = {
    "professional": {
        "primary": RGBColor(0x1A, 0x36, 0x5D),    # 深蓝
        "secondary": RGBColor(0x2E, 0x86, 0xAB),  # 浅蓝
        "accent": RGBColor(0xE8, 0x6F, 0x2C),     # 橙色
        "text_dark": RGBColor(0x2D, 0x2D, 0x2D),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF5, 0xF7, 0xFA),   # 浅灰背景
    },
    "creative": {
        "primary": RGBColor(0x6C, 0x5C, 0xE7),    # 紫色
        "secondary": RGBColor(0x00, 0xCE, 0xC9),  # 青色
        "accent": RGBColor(0xFD, 0x79, 0xA8),     # 粉色
        "text_dark": RGBColor(0x2D, 0x3A, 0x4A),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF8, 0xF9, 0xFA),   # 浅灰背景
    },
    "minimal": {
        "primary": RGBColor(0x33, 0x33, 0x33),    # 深灰
        "secondary": RGBColor(0x66, 0x66, 0x66),  # 中灰
        "accent": RGBColor(0x00, 0x7A, 0xCC),     # 蓝色
        "text_dark": RGBColor(0x1A, 0x1A, 0x1A),  # 黑色
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xFA, 0xFA, 0xFA),   # 极浅灰
    },
    "business": {
        "primary": RGBColor(0x0D, 0x47, 0xA1),    # 商务蓝
        "secondary": RGBColor(0x42, 0xA5, 0xF5),  # 亮蓝
        "accent": RGBColor(0xFF, 0xA0, 0x00),     # 金色
        "text_dark": RGBColor(0x21, 0x21, 0x21),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF5, 0xF5, 0xF5),   # 浅灰
    },
    "education": {
        "primary": RGBColor(0x25, 0x63, 0xEB),    # 活力蓝
        "secondary": RGBColor(0x10, 0xB9, 0x81),  # 草绿
        "accent": RGBColor(0xF5, 0x9E, 0x0B),     # 暖阳黄
        "text_dark": RGBColor(0x1E, 0x29, 0x3B),  # 深灰蓝
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xEF, 0xF6, 0xFF),   # 浅蓝灰
    },
    "fresh": {
        "primary": RGBColor(0xF4, 0x72, 0xB6),    # 珊瑚粉
        "secondary": RGBColor(0x34, 0xD3, 0x99),  # 薄荷绿
        "accent": RGBColor(0x60, 0xA5, 0xFA),     # 天空蓝
        "text_dark": RGBColor(0x37, 0x41, 0x51),  # 深灰
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xFF, 0xF1, 0xF2),   # 浅粉白
    },
    "nature": {
        "primary": RGBColor(0x16, 0x65, 0x34),    # 森林绿
        "secondary": RGBColor(0x92, 0x40, 0x0E),  # 大地棕
        "accent": RGBColor(0xEA, 0x58, 0x0C),     # 落叶橙
        "text_dark": RGBColor(0x1C, 0x19, 0x17),  # 深灰棕
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF0, 0xFD, 0xF4),   # 浅绿白
    },
    "ocean": {
        "primary": RGBColor(0x1E, 0x3A, 0x5F),    # 深海蓝
        "secondary": RGBColor(0xEF, 0x44, 0x44),  # 珊瑚红
        "accent": RGBColor(0x22, 0xD3, 0xEE),     # 海浪青
        "text_dark": RGBColor(0x1E, 0x29, 0x3B),  # 深灰蓝
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xF0, 0xF9, 0xFF),   # 浅蓝白
    },
    "warm": {
        "primary": RGBColor(0xC2, 0x41, 0x0C),    # 赤陶橙
        "secondary": RGBColor(0xD4, 0xA5, 0x74),  # 奶油黄(深)
        "accent": RGBColor(0x6B, 0x8E, 0x23),     # 鼠尾草绿
        "text_dark": RGBColor(0x3D, 0x2B, 0x1F),  # 深棕
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xFF, 0xF7, 0xED),   # 浅橙白
    },
    "ink": {
        "primary": RGBColor(0x1A, 0x1A, 0x2E),    # 墨黑
        "secondary": RGBColor(0xD4, 0xA5, 0x74),  # 宣纸黄
        "accent": RGBColor(0xC0, 0x39, 0x2B),     # 朱砂红
        "text_dark": RGBColor(0x1A, 0x1A, 0x2E),  # 墨黑
        "text_light": RGBColor(0xF5, 0xF0, 0xE8), # 宣纸白
        "bg_light": RGBColor(0xF5, 0xF0, 0xE8),   # 宣纸色
    },
    "playful": {
        "primary": RGBColor(0x8B, 0x5C, 0xF6),    # 活力紫
        "secondary": RGBColor(0xFA, 0xCC, 0x15),  # 明黄
        "accent": RGBColor(0x22, 0xC5, 0x5E),     # 翠绿
        "text_dark": RGBColor(0x2D, 0x1B, 0x69),  # 深紫
        "text_light": RGBColor(0xFF, 0xFF, 0xFF), # 白色
        "bg_light": RGBColor(0xFA, 0xF5, 0xFF),   # 浅紫白
    },
}

# 图表颜色方案（与主题匹配）
CHART_COLORS = {
    "professional": [RGBColor(0x1A, 0x36, 0x5D), RGBColor(0x2E, 0x86, 0xAB), RGBColor(0xE8, 0x6F, 0x2C)],
    "creative": [RGBColor(0x6C, 0x5C, 0xE7), RGBColor(0x00, 0xCE, 0xC9), RGBColor(0xFD, 0x79, 0xA8)],
    "minimal": [RGBColor(0x33, 0x33, 0x33), RGBColor(0x66, 0x66, 0x66), RGBColor(0x00, 0x7A, 0xCC)],
    "business": [RGBColor(0x0D, 0x47, 0xA1), RGBColor(0x42, 0xA5, 0xF5), RGBColor(0xFF, 0xA0, 0x00)],
    "education": [RGBColor(0x25, 0x63, 0xEB), RGBColor(0x10, 0xB9, 0x81), RGBColor(0xF5, 0x9E, 0x0B)],
    "fresh": [RGBColor(0xF4, 0x72, 0xB6), RGBColor(0x34, 0xD3, 0x99), RGBColor(0x60, 0xA5, 0xFA)],
    "nature": [RGBColor(0x16, 0x65, 0x34), RGBColor(0x92, 0x40, 0x0E), RGBColor(0xEA, 0x58, 0x0C)],
    "ocean": [RGBColor(0x1E, 0x3A, 0x5F), RGBColor(0xEF, 0x44, 0x44), RGBColor(0x22, 0xD3, 0xEE)],
    "warm": [RGBColor(0xC2, 0x41, 0x0C), RGBColor(0xD4, 0xA5, 0x74), RGBColor(0x6B, 0x8E, 0x23)],
    "ink": [RGBColor(0x1A, 0x1A, 0x2E), RGBColor(0xD4, 0xA5, 0x74), RGBColor(0xC0, 0x39, 0x2B)],
    "playful": [RGBColor(0x8B, 0x5C, 0xF6), RGBColor(0xFA, 0xCC, 0x15), RGBColor(0x22, 0xC5, 0x5E)],
}

# 教材版本配置
TEXTBOOK_CONFIG = {
    "renjia": {
        "name": "人教版",
        "structure": "unit_lesson",       # 按单元-课时组织
        "approach": "problem_driven",     # 问题驱动
        "exercise_tiers": ["基础", "提升", "拓展"],
        "theme_hint": {                   # 各学科推荐主题
            "语文": "warm", "数学": "education", "物理": "ocean",
            "化学": "ocean", "生物": "nature", "历史": "warm", "英语": "education",
        },
    },
    "sujiao": {
        "name": "苏教版",
        "structure": "theme_module",      # 按主题模块组织
        "approach": "method_oriented",    # 方法导向
        "exercise_tiers": ["基础", "思考", "拓展"],
        "theme_hint": {
            "语文": "ink", "数学": "education", "历史": "warm",
        },
    },
    "beishida": {
        "name": "北师大版",
        "structure": "inquiry_spiral",    # 探究螺旋上升
        "approach": "inquiry_based",      # 探究导向
        "exercise_tiers": ["探究", "合作", "反思"],
        "theme_hint": {
            "数学": "playful", "物理": "ocean", "生物": "nature",
        },
    },
    "hujiang": {
        "name": "沪教版",
        "structure": "tiered_expand",     # 分层拓展
        "approach": "tiered_design",      # 分层设计
        "exercise_tiers": ["基础", "提高", "拓展", "挑战"],
        "theme_hint": {
            "数学": "education", "英语": "education",
        },
    },
    "waiyan": {
        "name": "外研版",
        "structure": "topic_based",       # 话题式编排
        "approach": "topic_driven",       # 话题驱动
        "exercise_tiers": ["理解", "应用", "综合"],
        "theme_hint": {
            "英语": "education",
        },
    },
}

# 教材版本中文名→ID映射
TEXTBOOK_NAME_MAP = {
    "人教版": "renjia", "苏教版": "sujiao", "北师大版": "beishida",
    "沪教版": "hujiang", "外研版": "waiyan",
}

# 字体设置
FONTS = {
    "title_cn": "微软雅黑",
    "title_en": "Calibri",
    "body_cn": "微软雅黑",
    "body_en": "Calibri",
}


def set_slide_bg(slide, color):
    """设置幻灯片背景颜色"""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = color


def add_shape_with_fill(slide, left, top, width, height, color, shape_type=MSO_SHAPE.RECTANGLE):
    """添加带填充的矩形"""
    shape = slide.shapes.add_shape(shape_type, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    return shape


def add_text_box(slide, left, top, width, height, text, font_size=18, 
                 font_color=None, bold=False, alignment=PP_ALIGN.LEFT, font_name=None):
    """添加文本框"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.bold = bold
    p.alignment = alignment
    if font_color:
        p.font.color.rgb = font_color
    if font_name:
        p.font.name = font_name
    
    return txBox


def add_bullet_list(slide, left, top, width, height, items, font_size=16, 
                    font_color=None, bullet_color=None):
    """添加项目符号列表"""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        
        p.text = item
        p.font.size = Pt(font_size)
        p.level = 0
        p.space_before = Pt(8)
        p.space_after = Pt(4)
        if font_color:
            p.font.color.rgb = font_color
    
    return txBox


def create_title_slide(prs, data, theme):
    """创建标题页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 装饰条
    add_shape_with_fill(slide, Inches(0), Inches(3.2), Inches(10), Inches(0.05), theme["accent"])
    
    # 标题
    title = data.get("title", "演示文稿标题")
    add_text_box(slide, Inches(1), Inches(1.8), Inches(8), Inches(1.2),
                 title, font_size=44, font_color=theme["text_light"], 
                 bold=True, alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 副标题
    subtitle = data.get("subtitle", "")
    if subtitle:
        add_text_box(slide, Inches(1), Inches(3.5), Inches(8), Inches(0.8),
                     subtitle, font_size=24, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 作者/日期
    author = data.get("author", "")
    if author:
        add_text_box(slide, Inches(1), Inches(5.5), Inches(8), Inches(0.5),
                     author, font_size=16, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["body_cn"])
    
    return slide


def create_section_slide(prs, slide_data, theme):
    """创建章节分隔页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 左侧装饰条
    add_shape_with_fill(slide, Inches(0.5), Inches(2), Inches(0.1), Inches(3), theme["accent"])
    
    # 章节标题
    title = slide_data.get("title", "章节标题")
    add_text_box(slide, Inches(1.2), Inches(2.8), Inches(7.5), Inches(1.5),
                 title, font_size=40, font_color=theme["text_light"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    # 章节描述
    description = slide_data.get("description", "")
    if description:
        add_text_box(slide, Inches(1.2), Inches(4.5), Inches(7.5), Inches(1),
                     description, font_size=18, font_color=theme["text_light"],
                     alignment=PP_ALIGN.LEFT, font_name=FONTS["body_cn"])
    
    return slide


def create_content_slide(prs, slide_data, theme):
    """创建内容页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["bg_light"])
    
    # 顶部装饰条
    add_shape_with_fill(slide, Inches(0), Inches(0), Inches(10), Inches(0.08), theme["primary"])
    
    # 页面标题
    title = slide_data.get("title", "页面标题")
    add_text_box(slide, Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8),
                 title, font_size=28, font_color=theme["primary"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    # 标题下划线
    add_shape_with_fill(slide, Inches(0.8), Inches(1.2), Inches(2), Inches(0.04), theme["accent"])
    
    # 内容
    content = slide_data.get("content", "")
    if isinstance(content, list):
        add_bullet_list(slide, Inches(0.8), Inches(1.6), Inches(8.4), Inches(5),
                        content, font_size=18, font_color=theme["text_dark"])
    else:
        add_text_box(slide, Inches(0.8), Inches(1.6), Inches(8.4), Inches(5),
                     content, font_size=18, font_color=theme["text_dark"],
                     alignment=PP_ALIGN.LEFT, font_name=FONTS["body_cn"])
    
    # 备注
    notes = slide_data.get("notes", "")
    if notes:
        notes_slide = slide.notes_slide
        notes_slide.notes_text_frame.text = notes
    
    return slide


def create_two_column_slide(prs, slide_data, theme):
    """创建双栏布局页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["bg_light"])
    
    # 顶部装饰条
    add_shape_with_fill(slide, Inches(0), Inches(0), Inches(10), Inches(0.08), theme["primary"])
    
    # 页面标题
    title = slide_data.get("title", "页面标题")
    add_text_box(slide, Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8),
                 title, font_size=28, font_color=theme["primary"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    add_shape_with_fill(slide, Inches(0.8), Inches(1.2), Inches(2), Inches(0.04), theme["accent"])
    
    # 左栏
    left_content = slide_data.get("left_content", [])
    left_title = slide_data.get("left_title", "")
    
    if left_title:
        add_text_box(slide, Inches(0.8), Inches(1.6), Inches(4), Inches(0.6),
                     left_title, font_size=20, font_color=theme["secondary"],
                     bold=True, font_name=FONTS["title_cn"])
    
    if isinstance(left_content, list):
        add_bullet_list(slide, Inches(0.8), Inches(2.2), Inches(4), Inches(4.5),
                        left_content, font_size=16, font_color=theme["text_dark"])
    else:
        add_text_box(slide, Inches(0.8), Inches(2.2), Inches(4), Inches(4.5),
                     str(left_content), font_size=16, font_color=theme["text_dark"])
    
    # 分隔线
    add_shape_with_fill(slide, Inches(5), Inches(1.6), Inches(0.02), Inches(5), theme["secondary"])
    
    # 右栏
    right_content = slide_data.get("right_content", [])
    right_title = slide_data.get("right_title", "")
    
    if right_title:
        add_text_box(slide, Inches(5.3), Inches(1.6), Inches(4), Inches(0.6),
                     right_title, font_size=20, font_color=theme["secondary"],
                     bold=True, font_name=FONTS["title_cn"])
    
    if isinstance(right_content, list):
        add_bullet_list(slide, Inches(5.3), Inches(2.2), Inches(4), Inches(4.5),
                        right_content, font_size=16, font_color=theme["text_dark"])
    else:
        add_text_box(slide, Inches(5.3), Inches(2.2), Inches(4), Inches(4.5),
                     str(right_content), font_size=16, font_color=theme["text_dark"])
    
    return slide


def create_chart_slide(prs, slide_data, theme, theme_name="professional"):
    """创建图表页 - 支持柱状图、折线图、饼图"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["bg_light"])
    
    # 顶部装饰条
    add_shape_with_fill(slide, Inches(0), Inches(0), Inches(10), Inches(0.08), theme["primary"])
    
    # 页面标题
    title = slide_data.get("title", "数据图表")
    add_text_box(slide, Inches(0.8), Inches(0.4), Inches(8.4), Inches(0.8),
                 title, font_size=28, font_color=theme["primary"],
                 bold=True, alignment=PP_ALIGN.LEFT, font_name=FONTS["title_cn"])
    
    # 标题下划线
    add_shape_with_fill(slide, Inches(0.8), Inches(1.2), Inches(2), Inches(0.04), theme["accent"])
    
    # 获取图表数据
    chart_type = slide_data.get("chart_type", "bar")
    chart_title = slide_data.get("chart_title", "")
    categories = slide_data.get("categories", [])
    series_data = slide_data.get("series", [])
    
    # 创建图表数据
    chart_data = CategoryChartData()
    chart_data.categories = categories
    
    for s in series_data:
        chart_data.add_series(s.get("name", "数据"), s.get("values", []))
    
    # 确定图表类型
    if chart_type == "line":
        xl_chart_type = XL_CHART_TYPE.LINE_MARKERS
    elif chart_type == "pie":
        xl_chart_type = XL_CHART_TYPE.PIE
    else:  # bar (default)
        if len(series_data) > 1:
            xl_chart_type = XL_CHART_TYPE.COLUMN_CLUSTERED
        else:
            xl_chart_type = XL_CHART_TYPE.COLUMN_CLUSTERED
    
    # 图表位置和大小
    chart_left = Inches(0.8)
    chart_top = Inches(1.6)
    chart_width = Inches(8.4)
    chart_height = Inches(5.2)
    
    # 添加图表
    chart_frame = slide.shapes.add_chart(
        xl_chart_type, chart_left, chart_top, chart_width, chart_height, chart_data
    )
    chart = chart_frame.chart
    
    # 设置图表标题
    if chart_title:
        chart.has_title = True
        chart.chart_title.text_frame.paragraphs[0].text = chart_title
        chart.chart_title.text_frame.paragraphs[0].font.size = Pt(14)
        chart.chart_title.text_frame.paragraphs[0].font.name = FONTS["title_cn"]
    else:
        chart.has_title = False
    
    # 应用主题颜色到图表系列
    colors = CHART_COLORS.get(theme_name, CHART_COLORS["professional"])
    for i, series in enumerate(chart.series):
        color = colors[i % len(colors)]
        if chart_type == "pie":
            # 饼图：每个扇区不同颜色
            for j in range(len(categories)):
                point = series.points[j]
                point.format.fill.solid()
                point.format.fill.fore_color.rgb = colors[j % len(colors)]
        else:
            # 柱状图/折线图：每个系列一种颜色
            series.format.fill.solid()
            series.format.fill.fore_color.rgb = color
            if chart_type == "line":
                series.smooth = True
    
    # 图例设置
    if chart_type != "pie" or len(series_data) > 1:
        chart.has_legend = True
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False
    else:
        chart.has_legend = False
    
    # 备注
    notes = slide_data.get("notes", "")
    if notes:
        notes_slide = slide.notes_slide
        notes_slide.notes_text_frame.text = notes
    
    return slide


def create_quote_slide(prs, slide_data, theme):
    """创建引用/金句页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 引号装饰
    add_text_box(slide, Inches(1), Inches(1.5), Inches(1), Inches(1),
                 '"', font_size=80, font_color=theme["accent"],
                 bold=True, font_name=FONTS["title_en"])
    
    # 引用内容
    quote = slide_data.get("content", "")
    add_text_box(slide, Inches(1.5), Inches(2.5), Inches(7), Inches(2.5),
                 quote, font_size=28, font_color=theme["text_light"],
                 alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 来源
    source = slide_data.get("source", "")
    if source:
        add_text_box(slide, Inches(1.5), Inches(5.2), Inches(7), Inches(0.5),
                     f"— {source}", font_size=16, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["body_cn"])
    
    return slide


def create_end_slide(prs, data, theme):
    """创建结束页"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    set_slide_bg(slide, theme["primary"])
    
    # 装饰条
    add_shape_with_fill(slide, Inches(3), Inches(2.8), Inches(4), Inches(0.05), theme["accent"])
    
    # 感谢文字
    thanks_text = data.get("thanks_text", "感谢聆听")
    add_text_box(slide, Inches(1), Inches(3.2), Inches(8), Inches(1.2),
                 thanks_text, font_size=44, font_color=theme["text_light"],
                 bold=True, alignment=PP_ALIGN.CENTER, font_name=FONTS["title_cn"])
    
    # 联系方式
    contact = data.get("contact", "")
    if contact:
        add_text_box(slide, Inches(1), Inches(4.8), Inches(8), Inches(0.8),
                     contact, font_size=18, font_color=theme["text_light"],
                     alignment=PP_ALIGN.CENTER, font_name=FONTS["body_cn"])
    
    return slide


def resolve_textbook(textbook_input):
    """解析教材版本输入，支持ID和中文名"""
    if not textbook_input:
        return None
    # 先尝试直接匹配ID
    if textbook_input in TEXTBOOK_CONFIG:
        return textbook_input
    # 再尝试中文名映射
    if textbook_input in TEXTBOOK_NAME_MAP:
        return TEXTBOOK_NAME_MAP[textbook_input]
    # 模糊匹配
    for tid, cfg in TEXTBOOK_CONFIG.items():
        if cfg["name"] in textbook_input or textbook_input in cfg["name"]:
            return tid
    return None


def recommend_theme(textbook_id, subject=None):
    """根据教材版本和学科推荐主题"""
    if not textbook_id or textbook_id not in TEXTBOOK_CONFIG:
        return None
    config = TEXTBOOK_CONFIG[textbook_id]
    if subject and subject in config.get("theme_hint", {}):
        return config["theme_hint"][subject]
    return None


def create_ppt(input_file, output_file, theme_name="professional", textbook=None):
    """主函数：创建PPT"""
    # 读取JSON数据
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 解析教材版本（支持JSON中指定或参数指定）
    textbook_input = textbook or data.get("textbook", None)
    # 也支持教案JSON中meta.textbook字段
    if not textbook_input and "lesson_plan" in data:
        meta = data.get("lesson_plan", {}).get("meta", {})
        textbook_input = meta.get("textbook", None)
    
    textbook_id = resolve_textbook(textbook_input)
    
    # 获取主题
    theme = THEMES.get(theme_name, THEMES["professional"])
    if "theme" in data:
        theme_name = data["theme"]
        theme = THEMES.get(theme_name, theme)
    
    # 教材版本自动推荐主题（仅当用户未显式指定非默认主题时）
    if textbook_id and theme_name == "professional":
        subject = data.get("lesson_plan", {}).get("meta", {}).get("subject", None)
        recommended = recommend_theme(textbook_id, subject)
        if recommended and recommended in THEMES:
            theme_name = recommended
            theme = THEMES[theme_name]
    
    # 创建演示文稿
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(7.5)
    
    # 创建标题页
    create_title_slide(prs, data, theme)
    
    # 创建内容页
    slides = data.get("slides", [])
    for slide_data in slides:
        layout = slide_data.get("layout", "content")
        
        if layout == "section":
            create_section_slide(prs, slide_data, theme)
        elif layout == "two_column":
            create_two_column_slide(prs, slide_data, theme)
        elif layout == "chart":
            create_chart_slide(prs, slide_data, theme, theme_name)
        elif layout == "quote":
            create_quote_slide(prs, slide_data, theme)
        elif layout == "end":
            create_end_slide(prs, slide_data, theme)
        else:  # content
            create_content_slide(prs, slide_data, theme)
    
    # 如果没有结束页，添加一个
    if not slides or slides[-1].get("layout") != "end":
        create_end_slide(prs, {"thanks_text": "感谢聆听"}, theme)
    
    # 保存文件
    prs.save(output_file)
    
    result = {
        "status": "success",
        "output_file": str(output_file),
        "slide_count": len(prs.slides),
        "theme": theme_name,
    }
    if textbook_id:
        result["textbook"] = TEXTBOOK_CONFIG[textbook_id]["name"]
        result["textbook_id"] = textbook_id
    print(json.dumps(result, ensure_ascii=False))


def main():
    all_themes = list(THEMES.keys())
    all_textbooks = list(TEXTBOOK_CONFIG.keys()) + list(TEXTBOOK_NAME_MAP.keys())
    
    parser = argparse.ArgumentParser(description="大师级PPT生成脚本 v1.3")
    parser.add_argument("--input", required=True, help="JSON内容文件路径")
    parser.add_argument("--output", required=True, help="输出PPT文件路径")
    parser.add_argument("--theme", default="professional", 
                        choices=all_themes,
                        help="主题风格")
    parser.add_argument("--textbook", default=None,
                        help="教材版本(ID或中文名，如renjia/人教版/sujiao/苏教版/beishida/北师大版)")
    args = parser.parse_args()
    
    # 验证输入文件
    if not Path(args.input).exists():
        print(json.dumps({"status": "error", "message": f"输入文件不存在: {args.input}"}, ensure_ascii=False))
        sys.exit(1)
    
    try:
        create_ppt(args.input, args.output, args.theme, args.textbook)
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
